package com.qasystem.common;

import com.qasystem.common.response.Result;

/**
 * 📦 API响应类 - 统一API接口响应格式的便捷封装
 * 
 * 📖 功能说明：
 * ApiResponse是Result类的子类，提供了更简洁的API响应构建方式。
 * 它继承了Result的所有功能，同时提供了更符合语义的方法名，
 * 使代码更加清晰易读。
 * 
 * 🎯 设计目的：
 * 1. 提供更语义化的方法名，提高代码可读性
 * 2. 简化常见响应场景的代码编写
 * 3. 保持与Result类的完全兼容性
 * 4. 为Controller层提供统一的响应构建工具
 * 
 * 🔄 与Result的关系：
 * - 继承关系：ApiResponse extends Result
 * - 功能相同：两者都提供统一的API响应格式
 * - 使用场景：ApiResponse更注重语义化，Result更注重通用性
 * - 互操作性：两者可以完全互换使用
 * 
 * 📋 响应格式示例：
 * ```json
 * {
 *   "code": 200,
 *   "message": "操作成功",
 *   "data": {
 *     "id": 1,
 *     "title": "Java中的多态是什么？"
 *   },
 *   "timestamp": 1642345678
 * }
 * ```
 * 
 * 💡 使用场景：
 * 1. Controller层方法返回值
 * 2. Service层业务结果封装
 * 3. 异常处理器统一响应格式
 * 4. 微服务间接口调用响应
 * 
 * 🌟 优势特点：
 * - 语义化方法名，代码更易理解
 * - 泛型支持，类型安全
 * - 链式调用，代码更简洁
 * - 统一格式，前端处理更方便
 * 
 * @author 师生答疑系统开发团队
 * @since 1.0.0
 * @see Result 基础响应类，提供更通用的响应构建方法
 */
public class ApiResponse<T> extends Result<T> {

    /**
     * 🏗️ 无参构造函数 - 创建空的响应对象
     * 
     * 📖 功能说明：
     * 创建一个默认的ApiResponse实例，状态码、消息和数据为空，
     * 时间戳自动设置为当前时间。
     * 
     * 📋 使用场景：
     * - 后续通过setter方法设置属性
     * - 作为响应对象的初始状态
     * 
     * 🔄 等效操作：
     * ApiResponse<Void> response = new ApiResponse<>();
     * response.setCode(200);
     * response.setMessage("success");
     */
    public ApiResponse() {
        super();
    }

    /**
     * 🏗️ 状态码和消息构造函数 - 创建带状态码和消息的响应对象
     * 
     * 📖 功能说明：
     * 创建一个包含指定状态码和消息的ApiResponse实例，
     * 数据字段为空，时间戳自动设置为当前时间。
     * 
     * 📋 使用场景：
     * - 无需返回数据的成功响应
     * - 只需要错误信息的失败响应
     * - 状态检查接口的返回
     * 
     * 📝 参数说明：
     * @param code 响应状态码
     *             - 200: 操作成功
     *             - 400: 请求参数错误
     *             - 401: 未授权访问
     *             - 403: 禁止访问
     *             - 404: 资源不存在
     *             - 500: 服务器内部错误
     * @param message 响应消息，对操作结果的简要描述
     * 
     * 🔄 使用示例：
     * ApiResponse<Void> response = new ApiResponse<>(200, "登录成功");
     * ApiResponse<Void> errorResponse = new ApiResponse<>(404, "用户不存在");
     */
    public ApiResponse(Integer code, String message) {
        super(code, message);
    }

    /**
     * 🏗️ 完整构造函数 - 创建包含状态码、消息和数据的响应对象
     * 
     * 📖 功能说明：
     * 创建一个包含完整信息的ApiResponse实例，包括状态码、消息和数据，
     * 时间戳自动设置为当前时间。
     * 
     * 📋 使用场景：
     * - 需要返回数据的成功响应
     * - 包含错误详情的失败响应
     * - 复杂业务操作的返回结果
     * 
     * 📝 参数说明：
     * @param code 响应状态码，参考状态码构造函数的说明
     * @param message 响应消息，对操作结果的简要描述
     * @param data 响应数据，可以是任何类型的对象
     * 
     * 🔄 使用示例：
     * ApiResponse<User> response = new ApiResponse<>(200, "查询成功", user);
     * ApiResponse<List<Question>> listResponse = new ApiResponse<>(
     *     200, "查询成功", questionList);
     */
    public ApiResponse(Integer code, String message, T data) {
        super(code, message, data);
    }

    /**
     * ✅ 成功响应 - 创建无数据的成功响应
     * 
     * 📖 功能说明：
     * 创建一个表示操作成功的ApiResponse实例，状态码为200，
     * 消息为"success"，不包含数据。
     * 
     * 📋 使用场景：
     * - 删除操作成功
     * - 更新操作成功
     * - 无需返回数据的操作
     * 
     * 🔄 使用示例：
     * return ApiResponse.success(); // 返回成功响应
     * 
     * 📦 响应格式：
     * {
     *   "code": 200,
     *   "message": "success",
     *   "data": null,
     *   "timestamp": 1642345678
     * }
     * 
     * @param <T> 响应数据类型，此处为Void表示无数据
     * @return 成功响应对象
     */
    public static <T> ApiResponse<T> success() {
        return new ApiResponse<>(200, "success");
    }

    /**
     * ✅ 成功响应 - 创建带数据的成功响应
     * 
     * 📖 功能说明：
     * 创建一个表示操作成功并包含数据的ApiResponse实例，
     * 状态码为200，消息为"success"，包含指定的数据。
     * 
     * 📋 使用场景：
     * - 查询操作成功
     * - 创建操作成功并返回结果
     * - 需要返回数据的任何成功操作
     * 
     * 🔄 使用示例：
     * User user = userService.getById(1);
     * return ApiResponse.success(user); // 返回用户数据
     * 
     * List<Question> questions = questionService.list();
     * return ApiResponse.success(questions); // 返回问题列表
     * 
     * 📦 响应格式：
     * {
     *   "code": 200,
     *   "message": "success",
     *   "data": { ... },
     *   "timestamp": 1642345678
     * }
     * 
     * @param <T> 响应数据类型
     * @param data 要返回的数据对象
     * @return 包含数据的成功响应对象
     */
    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(200, "success", data);
    }

    /**
     * ✅ 成功响应 - 创建带数据和自定义消息的成功响应
     * 
     * 📖 功能说明：
     * 创建一个表示操作成功并包含数据和自定义消息的ApiResponse实例，
     * 状态码为200，消息为自定义内容，包含指定的数据。
     * 
     * 📋 使用场景：
     * - 需要自定义成功消息的场景
     * - 提供更详细的成功信息
     * - 国际化支持的多语言消息
     * 
     * 🔄 使用示例：
     * User user = userService.createUser(userInfo);
     * return ApiResponse.success(user, "用户创建成功");
     * 
     * 📦 响应格式：
     * {
     *   "code": 200,
     *   "message": "用户创建成功",
     *   "data": { ... },
     *   "timestamp": 1642345678
     * }
     * 
     * @param <T> 响应数据类型
     * @param data 要返回的数据对象
     * @param message 自定义成功消息
     * @return 包含数据和自定义消息的成功响应对象
     */
    public static <T> ApiResponse<T> success(T data, String message) {
        return new ApiResponse<>(200, message, data);
    }

//    /**
//     * ❌ 错误响应 - 创建带默认错误码的错误响应
//     *
//     * 📖 功能说明：
//     * 创建一个表示操作失败的ApiResponse实例，状态码为500（服务器内部错误），
//     * 消息为指定的错误内容，不包含数据。
//     *
//     * 📋 使用场景：
//     * - 业务逻辑异常
//     * - 数据处理错误
//     * - 服务器内部问题
//     *
//     * 🔄 使用示例：
//     * try {
//     *     // 业务逻辑
//     * } catch (Exception e) {
//     *     return ApiResponse.error("处理失败：" + e.getMessage());
//     * }
//     *
//     * 📦 响应格式：
//     * {
//     *   "code": 500,
//     *   "message": "处理失败：...",
//     *   "data": null,
//     *   "timestamp": 1642345678
//     * }
//     *
//     * @param <T> 响应数据类型，此处为Void表示无数据
//     * @param message 错误消息，描述失败原因
//     * @return 错误响应对象
//     */
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(500, message);
    }

    /**
     * ❌ 错误响应 - 创建自定义错误码的错误响应
     * 
     * 📖 功能说明：
     * 创建一个表示操作失败的ApiResponse实例，使用自定义的状态码和消息，
     * 不包含数据。
     * 
     * 📋 使用场景：
     * - 需要精确错误码的场景
     * - 客户端错误（4xx）
     * - 业务特定错误码
     * 
     * 🔄 使用示例：
     * return ApiResponse.error(400, "请求参数错误");
     * return ApiResponse.error(401, "未授权访问");
     * return ApiResponse.error(404, "资源不存在");
     * return ApiResponse.error(403, "禁止访问");
     * 
     * 📦 响应格式：
     * {
     *   "code": 400,
     *   "message": "请求参数错误",
     *   "data": null,
     *   "timestamp": 1642345678
     * }
     * 
     * @param <T> 响应数据类型，此处为Void表示无数据
     * @param code 自定义错误状态码
     * @param message 错误消息，描述失败原因
     * @return 包含自定义错误码的错误响应对象
     */
    public static <T> ApiResponse<T> error(Integer code, String message) {
        return new ApiResponse<>(code, message);
    }
}
