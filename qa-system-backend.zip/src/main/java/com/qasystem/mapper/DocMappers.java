package com.qasystem.mapper;

// 仅为占位文件，实际 Mapper 接口在单独文件中定义。
// 该文件避免空目录在某些构建/打包工具下被忽略，可根据需要删除。
