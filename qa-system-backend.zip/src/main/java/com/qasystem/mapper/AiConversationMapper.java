package com.qasystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qasystem.entity.AiConversation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * AiConversationMapper接口 - AI对话数据访问层
 * 
 * 🎯 作用说明：
 * 这个接口负责操作数据库中的ai_conversation表，就像一个"AI对话记录管理员"。
 * 管理着用户与AI助手的对话历史，就像ChatGPT的对话记录。
 * 每次用户提问和AI回答都会保存在这里，方便用户查看历史对话。
 * 
 * 📚 系统中的作用：
 * 1. 保存AI对话：记录用户问题和AI回答
 * 2. 查看历史对话：用户可以查看之前的对话记录
 * 3. 会话管理：管理多个对话会话（就像ChatGPT的不同对话）
 * 4. 上下文继续：继续之前的对话，AI能记住上文
 * 
 * 🏗️ 技术架构：
 * - 继承自MyBatis-Plus的BaseMapper<AiConversation>
 * - BaseMapper提供基础的增删改查方法
 * - 我们添加了2个自定义SQL查询方法：
 *   1. getSessionHistory：查询某个会话的完整历史
 *   2. getUserSessions：查询用户的所有会话列表
 * 
 * 📊 对应数据库表: ai_conversation
 * 
 * 🔗 数据结构：
 * - 字段：user_id, session_id, session_title, user_message, ai_response, created_at
 * - session_id：会话标识，同一会话的所有消息共享同session_id
 * - session_title：会话标题，通常是第一条消息的简要总结
 * 
 * 💡 使用场景：
 * 1. 用户向AI提问：保存问题和AI回答
 * 2. 查看历史对话：显示某个会话的完整记录
 * 3. 会话列表：显示用户的所有对话会话
 * 4. 继续对话：加载之前的对话上下文
 * 
 * ⚠️ 重要提示：
 * 1. @Select注解直接在接口中编写SQL，而不需要XML映射文件
 * 2. 这是一种简单快捷的方式，适用于简单SQL查询
 * 3. 复杂SQL建议使用XML映射文件，更易于维护
 * 4. session_id用于区分不同的对话会话
 * 
 * @author QA System Team
 * @version 1.0
 */
@Mapper
public interface AiConversationMapper extends BaseMapper<AiConversation> {
    
    /**
     * 获取用户的会话历史（按时间升序）
     * 
     * 🎯 方法作用：
     * 查询某个用户在某个会话中的完整对话历史，按时间升序排列。
     * 就像在ChatGPT中打开一个对话，看到从头到尾的所有问答。
     * 
     * 🔍 查询逻辑：
     * - 查询条件：user_id = ? AND session_id = ?
     * - 排序方式：按created_at升序（最早的消息在前）
     * - 这样可以按照时间顺序展示对话
     * 
     * 📝 使用场景：
     * 1. 加载对话页面：用户点击一个对话，加载完整历史
     * 2. 继续对话：继续之前的对话，AI需要了解上下文
     * 3. 导出对话：用户导出对话记录
     * 
     * @param userId 用户ID
     * @param sessionId 会话标识（UUID或时间戳生成）
     * @return List<AiConversation> 对话记录列表（按时间升序）
     *         - 包含用户问题和AI回答
     *         - 按照对话顺序排列
     */
    @Select("SELECT * FROM ai_conversation WHERE user_id = #{userId} AND session_id = #{sessionId} ORDER BY created_at ASC")
    List<AiConversation> getSessionHistory(Long userId, String sessionId);
    
    /**
     * 获取用户的所有会话列表
     * 
     * 🎯 方法作用：
     * 查询某个用户的所有对话会话，每个会话只返回最新的一条记录。
     * 就像在ChatGPT左侧边栏中显示的对话列表，每个对话显示标题和最后一次交互时间。
     * 
     * 🔍 查询逻辑详解：
     * 
     * 这是一个复杂SQL，使用了子查询和内连接：
     * 
     * 1. 子查询（t2）：
     *    - 对用户的所有对话按session_id分组
     *    - 找出每个会话中最新的一条记录的时间（MAX(created_at)）
     * 
     * 2. 主查询（t1）：
     *    - 查询ai_conversation表
     *    - 通过INNER JOIN关联子查询结果
     *    - 只选择每个会话中最新的那条记录
     * 
     * 3. 排序和限制：
     *    - 按created_at降序排列（最新的会话在前）
     *    - LIMIT #{limit}限制返回数量（例如20个最近的会话）
     * 
     * 📝 使用场景：
     * 1. 对话列表页面：显示用户的所有对话
     * 2. 侧边栏导航：就像ChatGPT左侧的对话列表
     * 3. 对话管理：用户可以选择、删除、重命名对话
     * 
     * 📝 返回数据示例：
     * [
     *   {sessionId: "uuid-1", sessionTitle: "如何学习Java", userMessage: "我是初学者...", createdAt: "2024-01-20"},
     *   {sessionId: "uuid-2", sessionTitle: "高等数学问题", userMessage: "请问导数...", createdAt: "2024-01-19"},
     *   {sessionId: "uuid-3", sessionTitle: "编程练习", userMessage: "写一个排序算法", createdAt: "2024-01-18"}
     * ]
     * 
     * @param userId 用户ID
     * @param limit 返回数量限制（例如20）
     * @return List<AiConversation> 会话列表（每个会话只返回最新一条）
     *         - 按时间降序排列（最新的在最前）
     *         - 包含sessionId, sessionTitle, userMessage, createdAt等字段
     * 
     * ⚠️ 注意事项：
     * 1. 这是一个复杂SQL，使用了子查询和JOIN，执行效率需要关注
     * 2. 建议在session_id和user_id上创建索引以提高性能
     * 3. limit参数应该有合理的范围限制（1-100）
     * 4. 如果用户有大量对话，建议使用分页查询
     * 5. sessionTitle通常是第一条消息的简要总结，用于显示在列表中
     */
    @Select("""
        SELECT 
            t1.id,
            t1.session_id,
            t1.session_title,
            t1.user_message,
            t1.created_at
        FROM ai_conversation t1
        INNER JOIN (
            SELECT session_id, MAX(created_at) as max_created_at
            FROM ai_conversation
            WHERE user_id = #{userId}
            GROUP BY session_id
        ) t2 ON t1.session_id = t2.session_id AND t1.created_at = t2.max_created_at
        WHERE t1.user_id = #{userId}
        ORDER BY t1.created_at DESC
        LIMIT #{limit}
    """)
    List<AiConversation> getUserSessions(Long userId, Integer limit);
}
