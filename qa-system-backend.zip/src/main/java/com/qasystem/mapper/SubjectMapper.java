package com.qasystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qasystem.entity.Subject;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * SubjectMapper接口 - 科目数据访问层
 * 
 * 🎯 作用说明：
 * 这个接口负责操作数据库中的subject表，就像一个"科目目录管理员"。
 * 管理着系统中所有可供选择的学科科目，比如：高等数学、线性代数、概率论、计算机网络等。
 * 
 * 📚 系统中的作用：
 * 1. 提供科目分类：学生提问时需要选择科目
 * 2. 问题筛选：教师根据科目筛选自己擅长的问题
 * 3. 教师标签：教师注册时选择擅长的科目
 * 4. 统计分析：查看每个科目的问题数量、热度等
 * 
 * 🏗️ 技术架构：
 * - 继承自MyBatis-Plus的BaseMapper<Subject>
 * - BaseMapper自动提供17个基础方法
 * - 我们添加了findAllActive()方法，用于查询所有启用的科目
 * - 科目有启用/禁用状态，只显示启用的科目给用户
 * 
 * 📊 对应数据库表: subject
 * 
 * 🔗 关联关系：
 * - 被question表关联：question.subject_id = subject.id （问题属于某个科目）
 * - 与teacher表多对多关联：通过teacher_subject中间表 （教师擅长多个科目）
 * 
 * 🔧 MyBatis-Plus提供的免费方法：
 * - insert(Subject s)：插入新科目
 * - deleteById(Long id)：删除科目
 * - updateById(Subject s)：更新科目信息
 * - selectById(Long id)：根据ID查询科目
 * - selectList(Wrapper)：查询科目列表
 * 
 * 💡 使用场景：
 * 1. 学生提问：显示科目下拉框供学生选择
 * 2. 问题列表筛选：根据科目查询问题
 * 3. 教师注册：选择擅长的科目
 * 4. 管理员管理：增加/修改/禁用科目
 * 5. 首页显示：显示热门科目
 * 
 * ⚠️ 重要提示：
 * 1. 这是一个接口，不需要编写实现类
 * 2. @Mapper注解让MyBatis自动生成实现代码
 * 3. 科目数据一般比较稳定，建议加入缓存（如Redis）
 * 4. 科目的排序顺序很重要，影响页面显示顺序
 * 
 * @author QA System Team
 * @version 1.0
 */
@Mapper
public interface SubjectMapper extends BaseMapper<Subject> {

    /**
     * 查询所有启用的科目（按排序）
     * 
     * 🎯 方法作用：
     * 查询所有状态为“启用”的科目，并按照指定的排序顺序返回。
     * 就像在选课系统中显示所有可选的课程，不显示已停开的课程。
     * 这是系统中非常常用的方法，建议将结果缓存起来。
     * 
     * 🔗 使用场景：
     * 
     * 1. 学生提问页面：
     *    - 显示科目下拉框，供学生选择问题所属科目
     *    - 只显示启用的科目，不显示已禁用的科目
     * 
     * 2. 问题列表筛选：
     *    - 在问题列表页面显示科目筛选器
     *    - 用户可以选择某个科目来筛选问题
     * 
     * 3. 教师注册/修改资料：
     *    - 显示科目多选框，教师选择擅长的科目
     *    - 只显示启用的科目
     * 
     * 4. 首页科目导航：
     *    - 显示科目分类导航栏
     *    - 用户点击科目可以看到该科目下的所有问题
     * 
     * 5. 管理员统计：
     *    - 统计每个科目的问题数量、回答率等
     *    - 只统计启用的科目
     * 
     * 🔍 查询逻辑详解：
     * 
     * 1. 创建LambdaQueryWrapper查询条件构造器
     * 
     * 2. .eq(Subject::getStatus, "ACTIVE")
     *    - 设置查询条件：status = 'ACTIVE'
     *    - 只查询启用的科目
     *    - ACTIVE表示启用，INACTIVE表示禁用
     * 
     * 3. .orderByAsc(Subject::getSortOrder, Subject::getId)
     *    - 按照排序字段（sort_order）升序
     *    - 如果sort_order相同，再按ID升序
     *    - sort_order是管理员手动设置的，用于控制科目显示顺序
     *    - 比如：高等数学（sort_order=1） > 线性代数（sort_order=2）
     * 
     * 4. selectList()执行查询，返回科目列表
     * 
     * 📝 使用示例1 - 学生提问时选择科目：
     * <pre>
     * // 获取所有启用的科目
     * List<Subject> subjects = subjectMapper.findAllActive();
     * 
     * // 在前端显示为下拉选择框
     * // <select name="subjectId">
     * for (Subject subject : subjects) {
     *     System.out.println("<option value=\"" + subject.getId() + "\">" 
     *         + subject.getName() + "</option>");
     *     // <option value="1">高等数学</option>
     *     // <option value="2">线性代数</option>
     * }
     * // </select>
     * </pre>
     * 
     * 📝 使用示例2 - 问题列表筛选器：
     * <pre>
     * // 获取所有启用的科目
     * List<Subject> subjects = subjectMapper.findAllActive();
     * 
     * // 返回给前端显示筛选按钮
     * return Result.success(subjects);
     * 
     * // 前端显示：[全部] [高等数学] [线性代数] [概率论]...
     * // 点击某个科目后，调用问题列表接口时传入subjectId
     * </pre>
     * 
     * 📝 使用示例3 - 教师选择擅长科目：
     * <pre>
     * // 教师修改资料，选择擅长科目
     * List<Subject> subjects = subjectMapper.findAllActive();
     * 
     * // 显示为多选框
     * // 教师可以选择多个科目，例如：[高等数学] 和 [线性代数]
     * // 选择后，保存到teacher_subject中间表
     * for (Long subjectId : selectedSubjectIds) {
     *     // INSERT INTO teacher_subject (teacher_id, subject_id) VALUES (?, ?)
     * }
     * </pre>
     * 
     * 📝 使用示例4 - 缓存优化：
     * <pre>
     * // 因为科目数据很少变化，建议使用缓存
     * List<Subject> subjects = redisTemplate.opsForValue().get("subjects:active");
     * 
     * if (subjects == null) {
     *     // 缓存不存在，从数据库查询
     *     subjects = subjectMapper.findAllActive();
     *     
     *     // 存入缓存，有效期1小时
     *     redisTemplate.opsForValue().set("subjects:active", subjects, 1, TimeUnit.HOURS);
     * }
     * 
     * return subjects;
     * </pre>
     * 
     * 🎯 实际执行的SQL：
     * SELECT id, name, description, status, sort_order, create_time, update_time
     * FROM subject
     * WHERE status = 'ACTIVE'
     * ORDER BY sort_order ASC, id ASC
     * 
     * 📊 返回示例数据：
     * [
     *   {id: 1, name: "高等数学", status: "ACTIVE", sortOrder: 1},
     *   {id: 2, name: "线性代数", status: "ACTIVE", sortOrder: 2},
     *   {id: 3, name: "概率论", status: "ACTIVE", sortOrder: 3},
     *   {id: 4, name: "计算机网络", status: "ACTIVE", sortOrder: 4}
     * ]
     * 
     * @return List<Subject> 启用的科目列表（按sort_order和id升序）
     *         - 如果没有启用的科目，返回空列表（不是null）
     *         - 科目按照sort_order排列，方便前端直接显示
     *         - 每个Subject对象包含id、name、description等字段
     * 
     * ⚠️ 注意事项：
     * 1. 这个方法是高频调用的，强烈建议加入缓存（Redis或应用缓存）
     * 2. 只返回status='ACTIVE'的科目，禁用的科目不会显示
     * 3. 排序顺序为：sort_order升序 > id升序
     * 4. 如果科目表为空，返回空列表，不会返回null
     * 5. 管理员修改科目（启用/禁用/更改排序）时，需要清除缓存
     * 6. sort_order字段很重要，建议设置为10、20、30...，以便未来插入新科目
     * 7. 返回的科目列表通常用于前端下拉框、筛选器、导航栏等组件
     */
    default List<Subject> findAllActive() {
        return selectList(new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Subject>()
                .eq(Subject::getStatus, "ACTIVE")
                .orderByAsc(Subject::getSortOrder, Subject::getId));
    }
}

