package com.qasystem.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * ChangePasswordRequest - 修改密码请求数据传输对象
 * 
 * 🎯 作用：用户修改密码时从前端接收的数据
 * 用于在个人中心“修改密码”功能，需要验证原密码才能修改。
 * 
 * 📝 字段说明：
 * - oldPassword: 原密码（必填），用于验证身份
 * - newPassword: 新密码（必填），必须符合密码强度要求
 * - confirmPassword: 确认密码（必填），必须与newPassword一致
 * 
 * 💬 请求示例：
 * {
 *   "oldPassword": "abc123",
 *   "newPassword": "newPass456",
 *   "confirmPassword": "newPass456"
 * }
 * 
 * ⚠️ 注意事项：
 * 1. 密码强度：必须包含字母和数字，长度6-20位，可包含特殊字符
 * 2. 后端会验证oldPassword是否正确
 * 3. 后端会验证newPassword和confirmPassword是否一致
 * 4. 建议密码在前端加密或通过HTTPS传输
 * 
 * 💡 使用场景：
 * - 用户在个人中心点击"修改密码"，填写表单后提交
 * - 前端会调用 POST /api/user/change-password 接口
 */
@Data
public class ChangePasswordRequest {
    
    /**
     * 原密码（必填）
     * 用于验证是否为本人操作，防止他人盗用账号
     * 后端会与数据库中的密码进行比对
     */
    @NotBlank(message = "原密码不能为空")
    private String oldPassword;
    
    /**
     * 新密码（必填）
     * 必顾符合密码强度要求：6-20位，包含字母和数字
     * 示例：newPass123, MyPwd2024
     */
    @NotBlank(message = "新密码不能为空")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d@$!%*#?&]{6,20}$", 
             message = "密码必须包含字母和数字，长度6-20位")
    private String newPassword;
    
    /**
     * 确认密码（必填）
     * 必须与新密码完全一致，防止用户输入错误
     * 后端会验证两次密码是否相同
     */
    @NotBlank(message = "确认密码不能为空")
    private String confirmPassword;
}

